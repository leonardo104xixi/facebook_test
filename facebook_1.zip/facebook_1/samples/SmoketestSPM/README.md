# SPM Integration Smoke Test

## This is just to smoke test that the repository cloned by the CI build can be integrated into a project and exposed Swift and Objective-C symbols we expect it to. 
